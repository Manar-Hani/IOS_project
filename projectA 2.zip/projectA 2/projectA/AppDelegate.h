//
//  AppDelegate.h
//  projectA
//
//  Created by iOS Training on 4/2/19.
//
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

