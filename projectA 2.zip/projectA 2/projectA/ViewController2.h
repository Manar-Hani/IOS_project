//
//  ViewController2.h
//  projectA
//
//  Created by iOS Training on 4/2/19.
//
//

#import <UIKit/UIKit.h>

@interface ViewController2 : UIViewController

@end
